interface IPerson {
  name: string
  age: number
}

interface IKun {
  slogan: string
}
