<template>
  <div class="home">
    <h2>home</h2>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>