export interface IFoo {
  name: string
  age: number
}

export type IDType = number | string
