export namespace Time {
  export function format(time: string) {
    return "2022-10-10"
  }

  export const name = "time"
}

export namespace Price {
  export function format(price: string) {
    return "¥20.00"
  }
}
