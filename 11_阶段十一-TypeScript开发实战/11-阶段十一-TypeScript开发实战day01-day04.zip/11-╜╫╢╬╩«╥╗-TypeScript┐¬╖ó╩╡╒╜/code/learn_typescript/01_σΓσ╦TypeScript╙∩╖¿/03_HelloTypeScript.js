"use strict";
// exports.__esModule = true;
// string: TypeScript给我们定义标识符时, 提供的字符串类型
// String: JavaScript中字符串的包装类
var message = "Hello World";
message = "Hello TypeScript";
// message = true
console.log(message);
