
// 定义标识符
let name: string = "why"
const age: number = 18
const height: number = 1.88

name = "kobe"
// name = 123

export {}
