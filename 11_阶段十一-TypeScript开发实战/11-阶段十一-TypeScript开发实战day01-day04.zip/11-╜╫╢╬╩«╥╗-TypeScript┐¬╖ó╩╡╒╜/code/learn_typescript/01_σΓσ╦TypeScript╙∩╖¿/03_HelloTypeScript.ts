// string: TypeScript给我们定义标识符时, 提供的字符串类型
// String: JavaScript中字符串的包装类
let message: string = "Hello World"
message = "Hello TypeScript"
// message = true

console.log(message)

export {}
