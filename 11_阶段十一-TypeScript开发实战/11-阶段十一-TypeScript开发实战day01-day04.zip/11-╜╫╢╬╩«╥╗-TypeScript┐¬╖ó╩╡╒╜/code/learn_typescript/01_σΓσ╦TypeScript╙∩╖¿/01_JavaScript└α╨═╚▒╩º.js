function getLength(args) {
  return args.length
}

// 调用函数
console.log(getLength("aaaa"))
console.log(getLength(["abc", "cba", "nba"]))


console.log(getLength(123))
console.log(getLength())

console.log("后续的代码")
