export const BASE_URL = "http://codercba.com:8000"
export const TIME_OUT = 10000
