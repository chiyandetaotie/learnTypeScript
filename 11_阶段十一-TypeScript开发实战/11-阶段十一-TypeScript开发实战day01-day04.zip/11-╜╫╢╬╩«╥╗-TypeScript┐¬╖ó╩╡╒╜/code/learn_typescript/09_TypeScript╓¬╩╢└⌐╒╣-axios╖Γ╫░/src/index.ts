import "./service/modules/home"
import "./service/modules/entire"

// webpack依赖图
