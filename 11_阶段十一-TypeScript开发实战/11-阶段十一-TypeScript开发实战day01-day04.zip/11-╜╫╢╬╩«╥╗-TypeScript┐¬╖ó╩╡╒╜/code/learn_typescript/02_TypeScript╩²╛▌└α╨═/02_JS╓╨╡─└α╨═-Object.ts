let info = {
  name: "why",
  age: 18,
  height: 1.88
}

console.log(info.name)
console.log(info.age)

export {}
