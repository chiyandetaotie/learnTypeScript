function foo(...args: (string | number)[]) {

}

foo(123, 321)
foo("abc", 111, "cba")
