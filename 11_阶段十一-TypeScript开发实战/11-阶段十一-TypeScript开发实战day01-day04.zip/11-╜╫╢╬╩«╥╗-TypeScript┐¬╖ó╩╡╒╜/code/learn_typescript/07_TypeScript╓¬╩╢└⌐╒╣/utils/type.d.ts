interface IPerson {
  name: string
  age: number
}

type IDType = number | string

