function foo(x: number, y = 10) {

}

foo(10, 20)
foo(10)
foo(10, undefined)

export {}
