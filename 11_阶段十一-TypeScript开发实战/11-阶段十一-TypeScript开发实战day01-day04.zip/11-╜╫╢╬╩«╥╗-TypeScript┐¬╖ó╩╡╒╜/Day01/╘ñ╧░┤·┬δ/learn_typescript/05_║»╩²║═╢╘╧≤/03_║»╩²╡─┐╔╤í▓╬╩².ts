function foo(x?: number) {
  console.log(x)
}

foo()
foo(123)
foo(undefined)


export {}
