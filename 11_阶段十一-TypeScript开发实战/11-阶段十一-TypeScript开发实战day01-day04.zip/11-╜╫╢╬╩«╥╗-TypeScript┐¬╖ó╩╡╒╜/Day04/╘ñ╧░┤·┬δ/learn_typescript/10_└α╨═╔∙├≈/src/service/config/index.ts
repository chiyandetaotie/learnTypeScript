export const BASE_URL1 = "http://codercba.com:8000"
export const TIME_OUT1 = 10000
